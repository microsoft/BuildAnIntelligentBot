declare const CreateGuid: () => string;
declare const CreateNoDashGuid: () => string;
export { CreateGuid, CreateNoDashGuid };
